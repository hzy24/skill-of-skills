import unittest,tempfile,sys,json,argparse
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import bench,run
class KitTests(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
 def tearDown(self):self.tmp.cleanup()
 def test_sampling_24_unique(self):
  batches=bench.sample_rounds(list(range(1,101)),4,6,20261105)
  self.assertEqual([len(x) for x in batches],[6]*4);self.assertEqual(len(set(sum(batches,[]))),24)
  self.assertEqual(batches,bench.sample_rounds(list(range(1,101)),4,6,20261105))
 def test_sample_too_large(self):
  with self.assertRaises(ValueError):bench.sample_rounds([1,2],4,6,1)
 def test_ids(self):self.assertEqual(bench.ids('1-3,3,5'),[1,2,3,5])
 def test_invalid_ids(self):
  with self.assertRaises(ValueError):bench.ids('0')
 def test_metric_exact(self):self.assertEqual(bench.metric(['same finding'],['same finding'])['f1'],100)
 def test_metric_extra_claim_penalty(self):self.assertLess(bench.metric(['same','unrelated'],['same'])['f1'],100)
 def test_path_traversal(self):
  with self.assertRaises(ValueError):bench.safe(self.root,'../outside')
 def test_missing_is_null(self):
  bench.save(self.root/'manifest.json',{'tasks':[{'id':1}],'repetitions':1});bench.save(self.root/'refs.json',{'1':{'insights':['x']}})
  bench.score(argparse.Namespace(runner=str(self.root),references=str(self.root/'refs.json'),translations=None,output=str(self.root/'scores')))
  self.assertTrue(all(x['f1'] is None for x in bench.load(self.root/'scores/scores.json')['rows']))
 def test_chinese_needs_translation(self):
  bench.save(self.root/'manifest.json',{'tasks':[{'id':1}],'repetitions':1});bench.save(self.root/'refs.json',{'1':{'insights':['x']}});bench.save(self.root/'runs/1/1/A/prediction.json',{'insights':['中文']})
  bench.score(argparse.Namespace(runner=str(self.root),references=str(self.root/'refs.json'),translations=None,output=str(self.root/'scores')))
  self.assertEqual(bench.load(self.root/'scores/scores.json')['rows'][0]['status'],'translation_required')
 def test_stale_translation_rejected(self):
  bench.save(self.root/'manifest.json',{'tasks':[{'id':1}],'repetitions':1});bench.save(self.root/'refs.json',{'1':{'insights':['x']}});bench.save(self.root/'runs/1/1/A/prediction.json',{'insights':['中文']});bench.save(self.root/'tr/1-1-A.json',{'source_sha256':'wrong','reviewed_by':'tester'})
  with self.assertRaises(AssertionError):bench.score(argparse.Namespace(runner=str(self.root),references=str(self.root/'refs.json'),translations=str(self.root/'tr'),output=str(self.root/'scores')))
 def test_b_requires_c(self):
  with self.assertRaises(ValueError):run.verified_caps(self.root,1,1)
 def test_no_duplicate_dispatch(self):
  out=self.root/'run';out.mkdir();bench.save(out/'execution-request.json',{})
  with patch.object(run,'observe') as observe,patch.object(run.t,'get') as get:
   run.dispatch(out,'execution','do not resend',None,self.root);observe.assert_called_once();get.assert_not_called()
 def test_ingest_hash(self):
  out=self.root/'runs/1/1/A';bench.save(out/'artifacts.json',[{'saved':'findings.json','sha256':'wrong'}]);bench.save(out/'findings.json',{'insights':['x']})
  with self.assertRaises(ValueError):run.ingest(self.root,1,1,'A',out/'findings.json')
 def test_b_freeze_tampering(self):
  out=self.root/'runs/1/1/C';bench.save(out/'prediction.json',{'insights':['x']});bench.save(out/'execution-snapshot.json',{'events':[{'id':'e1'}]});bench.save(out/'matched-skills.json',{'reviewed_by':'reviewer','skills':[{'name':'skill','evidence_event_ids':['e1'],'files':[{'path':'skill.md','sha256':'wrong'}]}]});(self.root/'skill.md').write_text('changed')
  with self.assertRaises(ValueError):run.verified_caps(self.root,1,1)
if __name__=='__main__':unittest.main()

class EndToEndOffline(unittest.TestCase):
 def test_all_groups_scored_with_rounds_and_official_exports(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);bench.save(root/'manifest.json',{'tasks':[{'id':1,'round':1}],'repetitions':1})
   bench.save(root/'refs.json',{'1':{'insights':['expense duplicates']}})
   for group in 'ABC':bench.save(root/f'runs/1/1/{group}/prediction.json',{'insights':['expense duplicates']})
   bench.score(argparse.Namespace(runner=str(root),references=str(root/'refs.json'),translations=None,output=str(root/'result')))
   result=bench.load(root/'result/scores.json');self.assertEqual(result['complete_case_means'],dict(A=100,B=100,C=100));self.assertEqual(result['round_scores']['1']['C']['scored'],1)
   self.assertEqual(len(list((root/'result/official-predictions').glob('*.json'))),3)
 def test_observer_completion_without_resend(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);out=root/'run';out.mkdir();bench.save(out/'conversation.json',{'id':'c1'});bench.save(out/'execution-request.json',{'message_id':'m1','content':'task'});bench.save(out/'execution-start.json',{'epoch':0})
   snap={'events':[{'kind':'user_message','id':'m1','content':'task'}],'streaming':False,'turn_state':'idle'}
   with patch.object(run.t,'get',return_value=snap),patch.object(run.t,'download') as download,patch.object(run.time,'sleep'):
    run.observe(out,'execution',root);self.assertTrue((out/'execution-snapshot.json').exists());download.assert_called_once()
 def test_stop_prevents_new_task(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);(root/'STOP').touch()
   with patch.object(run.t,'post') as post:
    with self.assertRaises(ValueError):run.start(root,{'id':1},1,'A')
    post.assert_not_called()
