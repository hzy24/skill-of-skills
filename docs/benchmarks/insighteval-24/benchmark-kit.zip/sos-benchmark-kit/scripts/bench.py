#!/usr/bin/env python3
"""Portable InsightEval experiment preparation and evidence-preserving evaluation."""
import argparse, collections, hashlib, json, random, re, shutil, statistics
from pathlib import Path

def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def save(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_suffix(p.suffix+'.tmp');q.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8');q.replace(p)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ids(s):
 out=set()
 for part in s.split(','):
  a=part.split('-');out.update(range(int(a[0]),int(a[-1])+1))
 if not out or min(out)<1 or max(out)>100:raise ValueError('IDs must be within 1–100')
 return sorted(out)
def safe(root,rel):
 p=(Path(root)/rel).resolve()
 if not p.is_relative_to(Path(root).resolve()):raise ValueError('Path outside run root')
 return p

def sample_rounds(candidates, rounds, per_round, seed):
 if rounds < 1 or per_round < 1 or rounds*per_round > len(candidates):raise ValueError("Sample exceeds candidate pool or invalid rounds")
 selected=random.Random(seed).sample(sorted(candidates),rounds*per_round)
 return [selected[i*per_round:(i+1)*per_round] for i in range(rounds)]

def prepare(a):
 if a.repetitions < 1:raise ValueError('repetitions must be positive')
 root=Path(a.output).resolve()
 if root.exists():raise ValueError('Output exists: choose a new experiment directory')
 dataset=Path(a.dataset).resolve();tasks=[];refs={};custom=load(a.prompts) if a.prompts else {}
 batches=sample_rounds(ids(a.ids),a.rounds,a.per_round,a.seed)
 round_of={i:n+1 for n,batch in enumerate(batches) for i in batch}
 for i in [i for batch in batches for i in batch]:
  doc=load(dataset/f'data/jsons/data_{i}.json');meta=doc['metadata'];files=[]
  for field in ['table_path','user_table_path']:
   if not meta.get(field):continue
   name=Path(meta[field]).name.replace('-','_');src=dataset/'data/csvs'/name
   if not src.is_file():raise FileNotFoundError(src)
   dst=root/'runner/inputs'/str(i)/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
   files.append({'path':str(dst.relative_to(root/'runner')),'sha256':sha(dst)})
  goal=custom.get(str(i)) if custom else doc['goal']
  if not isinstance(goal,str) or not goal.strip():raise ValueError(f'Missing prompt {i}')
  tasks.append({'id':i,'round':round_of[i],'goal':goal,'category':meta['category'],'difficulty':meta['difficulty'],'files':files})
  refs[str(i)]={'insights':doc['insights'],'source_sha256':sha(dataset/f'data/jsons/data_{i}.json')}
 skill=Path(a.skill).resolve();dest=root/'runner/frozen-skill';shutil.copytree(skill,dest,ignore=shutil.ignore_patterns('__pycache__','.git','*.pyc'))
 skill_hashes={str(p.relative_to(dest)):sha(p) for p in sorted(dest.rglob('*')) if p.is_file()}
 common='Deliver the analysis and supporting calculations as files. Also deliver findings.json with {"insights": ["one substantive finding with evidence per string"], "summary": "..."}. Include your actual findings without padding to a fixed count.'
 manifest={'schema':'sos-benchmark-v1','protocol':'everyday-adapted' if custom else 'official-goal','tasks':tasks,'repetitions':a.repetitions,'model_id':a.model,'base_url':a.base_url,'planning_limit_seconds':a.planning_limit,'execution_limit_seconds':None,'common_output_instruction':common,'skill_sha256':skill_hashes,'task_order_seed':a.seed,'notes':'Each task/group/repetition uses a fresh conversation. C first; B gets only frozen skill files, never C plan or findings. A has ordinary native tools; skill access must be isolated by operator.'}
 manifest['sampling']={'method':'uniform_without_replacement','rounds':batches,'seed':a.seed,'candidate_ids':ids(a.ids),'runs_per_group':len(tasks)*a.repetitions,'total_runs':len(tasks)*a.repetitions*3}
 save(root/'runner/manifest.json',manifest);save(root/'evaluator/references.json',refs)
 save(root/'evaluator/protocol.json',{'manifest_sha256':sha(root/'runner/manifest.json'),'ids':[t['id'] for t in tasks],'protocol':manifest['protocol']})
 print(root)

def overlap(a,b):
 a=collections.Counter(re.findall(r'\w+',a.lower()));b=collections.Counter(re.findall(r'\w+',b.lower()));n=sum((a&b).values());return 2*n/(sum(a.values())+sum(b.values())) if a and b else 0.
def metric(pred,ref):
 r=statistics.mean(max((overlap(x,y) for y in pred),default=0) for x in ref) if ref else 0
 p=statistics.mean(max((overlap(x,y) for y in ref),default=0) for x in pred) if pred else 0
 return {'recall':r*100,'precision':p*100,'f1':200*r*p/(r+p) if r+p else 0}

def translations(a):
 root=Path(a.runner);out=Path(a.output)
 if out.exists():raise ValueError('Translation directory exists')
 for p in root.glob('runs/*/*/*/prediction.json'):
  d=load(p);items=d['insights'];key='-'.join(p.parts[-4:-1]);save(out/(key+'.json'),{'source_sha256':sha(p),'records':[{'id':n,'source':s,'english':s if not re.search('[\u4e00-\u9fff]',s) else None} for n,s in enumerate(items)],'reviewed_by':None})
 (out/'INSTRUCTIONS.txt').write_text('Translate each source faithfully. Preserve errors, numbers, caveats and claim strength. Do not consult references or add findings. Keep IDs and sources unchanged; fill english and reviewed_by. No summaries. Blank translations are rejected.\n')

def score(a):
 root=Path(a.runner);manifest=load(root/'manifest.json');refs=load(a.references);rows=[];official=Path(a.output)/'official-predictions'
 if Path(a.output).exists():raise ValueError('Use a fresh scoring output directory')
 official.mkdir(parents=True,exist_ok=True)
 for task in manifest['tasks']:
  for rep in range(1,manifest['repetitions']+1):
   for g in 'ABC':
    run=root/'runs'/str(task['id'])/str(rep)/g;p=run/'prediction.json';row={'instance_id':task['id'],'round':task.get('round',1),'repetition':rep,'group':g,'status':'missing','f1':None}
    if p.exists():
     d=load(p);pred=d.get('insights');assert isinstance(pred,list) and all(isinstance(x,str) and x.strip() for x in pred),'Invalid insights'
     if not pred:row['status']='empty_prediction'
     else:
      tp=Path(a.translations)/f"{task['id']}-{rep}-{g}.json" if a.translations else None
      if tp and tp.exists():
       tr=load(tp);assert tr['source_sha256']==sha(p) and tr.get('reviewed_by'),'Unreviewed or stale translation'
       assert len(tr['records'])==len(pred),'Incomplete translation'
       for n,(record,source) in enumerate(zip(tr['records'],pred)):
        assert record['id']==n and record['source']==source and isinstance(record['english'],str) and record['english'].strip(),'Translation mismatch'
       pred=[x['english'] for x in tr['records']]
      if any(re.search('[\u4e00-\u9fff]',x) for x in pred):row['status']='translation_required'
      else:
       row.update(status='scored',**metric(pred,refs[str(task['id'])]['insights']));save(official/f"{task['id']}-{rep}-{g}.json",{'insights':pred})
     row['prediction_sha256']=sha(p)
    rows.append(row)
 means={g:statistics.mean(x['f1'] for x in rows if x['group']==g and x['f1'] is not None) if any(x['group']==g and x['f1'] is not None for x in rows) else None for g in 'ABC'}
 pairs=[]
 for task in manifest['tasks']:
  rr=[x for x in rows if x['instance_id']==task['id']];group={g:[x['f1'] for x in rr if x['group']==g and x['f1'] is not None] for g in 'ABC'}
  if all(len(v)==manifest['repetitions'] for v in group.values()):pairs.append({g:statistics.mean(v) for g,v in group.items()})
 diffs={}
 for base in 'AB':
  values=[p['C']-p[base] for p in pairs];rng=random.Random(20261105)
  boot=sorted(statistics.mean(rng.choices(values,k=len(values))) for _ in range(5000)) if values else []
  diffs['C-'+base]={'paired_tasks':len(values),'mean_difference':statistics.mean(values) if values else None,'task_bootstrap_95_percent_interval':[boot[125],boot[4874]] if boot else None}
 round_scores={str(n):{g:{'scored':len([x for x in rows if x['round']==n and x['group']==g and x['f1'] is not None]),'mean':statistics.mean(x['f1'] for x in rows if x['round']==n and x['group']==g and x['f1'] is not None) if any(x['round']==n and x['group']==g and x['f1'] is not None for x in rows) else None} for g in 'ABC'} for n in sorted(set(x['round'] for x in rows))}
 save(Path(a.output)/'scores.json',{'metric':'local-ROUGE1-best-match-not-semantic-judge','rows':rows,'round_scores':round_scores,'available_means':means,'complete_case_means':{g:statistics.mean(p[g] for p in pairs) if pairs else None for g in 'ABC'},'paired_differences':diffs,'missing_policy':'Missing/failed/untranslated are null, never silently zero. Available means are not comparable if coverage differs.'})
 print(json.dumps({'available_means':means,'paired_differences':diffs},indent=2))

def main():
 p=argparse.ArgumentParser();sub=p.add_subparsers(dest='cmd',required=True)
 s=sub.add_parser('prepare');s.add_argument('--dataset',required=True);s.add_argument('--skill',required=True);s.add_argument('--output',required=True);s.add_argument('--ids',default='1-100');s.add_argument('--rounds',type=int,default=4);s.add_argument('--per-round',type=int,default=6);s.add_argument('--repetitions',type=int,default=1);s.add_argument('--model',required=True);s.add_argument('--base-url',default='http://127.0.0.1:62774');s.add_argument('--prompts');s.add_argument('--seed',type=int,default=20261105);s.add_argument('--planning-limit',type=int,default=1800);s.set_defaults(func=prepare)
 s=sub.add_parser('translations');s.add_argument('--runner',required=True);s.add_argument('--output',required=True);s.set_defaults(func=translations)
 s=sub.add_parser('score');s.add_argument('--runner',required=True);s.add_argument('--references',required=True);s.add_argument('--translations');s.add_argument('--output',required=True);s.set_defaults(func=score)
 a=p.parse_args();a.func(a)
if __name__=='__main__':main()
