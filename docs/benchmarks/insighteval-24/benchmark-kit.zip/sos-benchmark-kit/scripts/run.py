#!/usr/bin/env python3
"""Yuanjing local API adapter. Durable one-shot dispatch and resumable observation."""
import argparse, concurrent.futures, hashlib, json, os, threading, time, uuid, zipfile
from pathlib import Path
from bench import load,save,sha,safe
import yuanjing_transport as t
CREATE=threading.Lock()

def runpath(root,task,rep,g):return root/'runs'/str(task)/str(rep)/g

def observe(out,phase,root):
 req=load(out/(phase+'-request.json'));start=load(out/(phase+'-start.json'));cid=load(out/'conversation.json')['id'];idle=0
 while True:
  if (root/'STOP').exists():
   save(out/(phase+'-observer-status.json'),{'status':'observer_paused','remote_task_not_stopped':True});return
  try:
   snap=t.get('/api/conversations/'+cid);save(out/(phase+'-live.json'),snap)
   active=snap.get('streaming') or snap.get('turn_state') in ('running','streaming','queued')
   seen=any(e.get('kind')=='user_message' and (e.get('id')==req['message_id'] or e.get('content')==req['content']) for e in snap.get('events',[]))
   idle=idle+1 if seen and not active else 0
   if idle>=2:
    save(out/(phase+'-snapshot.json'),snap);save(out/(phase+'-metrics.json'),{'status':'turn_finished_not_quality_verdict','wall_seconds':time.time()-start['epoch'],'model_id':t.MODEL});t.download(cid,out,snap);return
   if phase=='planning' and time.time()-start['epoch']>load(root/'manifest.json')['planning_limit_seconds']:
    t.post('/api/chat/'+cid+'/stop',{});save(out/(phase+'-metrics.json'),{'status':'planning_timeout','wall_seconds':time.time()-start['epoch']});return
  except Exception as e:
   with (out/'observer-errors.jsonl').open('a') as f:f.write(json.dumps({'epoch':time.time(),'error':str(e)})+'\n')
  time.sleep(5)

def dispatch(out,phase,prompt,attachments,root):
 lock=out/(phase+'-request.json')
 if lock.exists():return observe(out,phase,root) if not (out/(phase+'-metrics.json')).exists() else None
 cid=load(out/'conversation.json')['id'];snapshot=t.get('/api/conversations/'+cid)
 if snapshot.get('streaming'):raise RuntimeError('Session busy')
 request={'content':prompt,'model_id':t.MODEL,'message_id':str(uuid.uuid4()),'parent_message_id':snapshot.get('active_leaf_id'),'attachments':attachments}
 # Exclusive durable claim before network write. Unknown delivery is never resent.
 with lock.open('x') as f:json.dump(request,f,ensure_ascii=False,indent=2)
 save(out/(phase+'-start.json'),{'epoch':time.time()})
 def send():
  try:
   req=t.urllib.request.Request(t.BASE+'/api/chat/'+cid+'/message',data=json.dumps(request).encode(),headers={'Content-Type':'application/json'})
   with t.op.open(req,timeout=120) as stream,(out/(phase+'.sse')).open('wb') as f:
    for line in stream:f.write(line);f.flush()
  except Exception as e:save(out/(phase+'-transport-error.json'),{'error':str(e),'action':'observe existing session; never resend'})
 threading.Thread(target=send,daemon=True).start();observe(out,phase,root)

def verified_caps(root,task,rep):
 c=runpath(root,task,rep,'C')
 if not (c/'prediction.json').exists():raise ValueError('C must deliver validated findings before B')
 match=load(c/'matched-skills.json');snapshot=load(c/'execution-snapshot.json');events={e['id'] for e in snapshot.get('events',[])}
 if not match.get('reviewed_by') or not match.get('skills'):raise ValueError('C actual skill audit required')
 for cap in match['skills']:
  if not cap.get('evidence_event_ids') or not set(cap['evidence_event_ids'])<=events:raise ValueError('Missing C evidence events')
  if not cap.get('files'):raise ValueError('Freeze all skill files')
  for f in cap['files']:
   if sha(safe(root,f['path']))!=f['sha256']:raise ValueError('Skill hash mismatch')
 return match['skills']

def start(root,task,rep,g):
 if (root/'STOP').exists():raise ValueError('Queue paused by STOP')
 manifest=load(root/'manifest.json');out=runpath(root,task['id'],rep,g);out.mkdir(parents=True,exist_ok=True)
 attestation=load(root/'environment-attestation.json')
 if not attestation.get('reviewed_by') or attestation.get('model_id')!=t.MODEL or not attestation.get('isolated_sessions') or not attestation.get('group_skill_isolation'):raise ValueError('Operator must attest model and environment isolation')
 if g=='C' and attestation.get('installed_sos_entry_sha256')!=manifest['skill_sha256'].get('SKILL.md'):raise ValueError('Installed SoS entry hash must match frozen version')
 for rel,h in manifest['skill_sha256'].items():
  if sha(root/'frozen-skill'/rel)!=h:raise ValueError('Frozen SoS changed')
 caps=verified_caps(root,task['id'],rep) if g=='B' else []
 phase='planning' if g=='C' else 'execution'
 if (out/(phase+'-request.json')).exists():return dispatch(out,phase,'',None,root)
 if (out/'conversation.json').exists() or (out/'setup-claim.json').exists():raise ValueError('Interrupted setup: inspect existing conversation; no automatic new session')
 with CREATE:
  with (out/'setup-claim.json').open('x') as claim:json.dump({'epoch':time.time()},claim)
  session=t.post('/api/sessions',{'mode':'cowork','model_id':t.MODEL});save(out/'session.json',session)
  conv=t.post('/api/conversations',{'title':f"InsightEval {task['id']} r{rep} {g}",'mode':'cowork','model_id':t.MODEL,'session_id':session['session_id']});save(out/'conversation.json',conv)
  attachments=[]
  for item in task['files']:
   p=safe(root,item['path'])
   if sha(p)!=item['sha256']:raise ValueError('Input changed')
   uploaded=t.upload(conv['id'],p);attachments.append({'filename':p.name,'path':uploaded['path']})
  if caps:
   pack=out/'matched-skills.zip'
   with zipfile.ZipFile(pack,'w',zipfile.ZIP_DEFLATED) as z:
    for n,cap in enumerate(caps):
     for f in cap['files']:
      archive=Path(f['relative_path'])
      if archive.is_absolute() or '..' in archive.parts:raise ValueError('Unsafe skill archive path')
      z.write(safe(root,f['path']),f'skill-{n}/'+str(archive))
   uploaded=t.upload(conv['id'],pack);attachments.append({'filename':pack.name,'path':uploaded['path']})
  save(out/'attachments.json',attachments)
 prompt=task['goal']+'\n'+manifest['common_output_instruction']
 if g=='C':prompt+='\nUse Skill of Skills. First deliver plan.json and plan.html for review, then wait for confirmation before executing.'
 elif g=='B':prompt+='\nDo not use Skill of Skills. Use the attached frozen skills and follow their methods; choose your own steps. Do not add other professional skills. Skills: '+', '.join(c['name'] for c in caps)
 else:prompt+='\nComplete the task directly without Skill of Skills or other professional skills; ordinary native tools remain available.'
 dispatch(out,phase,prompt,attachments,root)

def execute(root,task,rep,approval):
 if (root/'STOP').exists():raise ValueError('Queue paused by STOP')
 out=runpath(root,task,rep,'C');review=load(approval);artifacts=load(out/'artifacts.json');plans=[x for x in artifacts if x.get('saved') and Path(x['source']).name=='plan.json']
 if len(plans)!=1:raise ValueError('One delivered plan.json required')
 p=out/plans[0]['saved']
 if not review.get('reviewed_by') or review.get('plan_sha256')!=sha(p) or review.get('approved') is not True or not review.get('execution_prompt'):raise ValueError('Explicit approval bound to plan hash required')
 save(out/'execution-approval.json',review);dispatch(out,'execution',review['execution_prompt'],None,root)

def collect(root):
 rows=[]
 for out in root.glob('runs/*/*/*'):
  if not out.is_dir():continue
  seen=set();usage={'input_tokens':0,'output_tokens':0,'cache_read_input_tokens':0};missing=0;phases={}
  for phase in ['planning','execution']:
   p=out/(phase+'-snapshot.json')
   if not p.exists():continue
   phases[phase]=load(out/(phase+'-metrics.json'))
   for event in load(p).get('events',[]):
    if event.get('id') in seen:continue
    seen.add(event.get('id'))
    if event.get('kind')!='assistant_message':continue
    if not event.get('usage'):missing+=1
    for k in usage:usage[k]+=(event.get('usage') or {}).get(k) or 0
  rows.append({'instance_id':out.parts[-3],'repetition':out.parts[-2],'group':out.name,'phases':phases,'usage':usage,'messages_without_usage':missing})
 save(root/'resources.json',rows)

def ingest(root,task,rep,g,source):
 out=runpath(root,task,rep,g);p=Path(source).resolve();artifacts=load(out/'artifacts.json')
 matches=[x for x in artifacts if x.get('saved') and (out/x['saved']).resolve()==p]
 if not matches or matches[0]['sha256']!=sha(p):raise ValueError('Use a hash-verified delivered artifact')
 d=load(p)
 if not isinstance(d.get('insights'),list) or not all(isinstance(x,str) and x.strip() for x in d['insights']):raise ValueError('Invalid findings.json')
 if (out/'prediction.json').exists():raise ValueError('Prediction already ingested; never overwrite')
 save(out/'prediction.json',d);save(out/'prediction-source.json',matches[0])

def main():
 p=argparse.ArgumentParser();p.add_argument('--runner',required=True);s=p.add_subparsers(dest='action',required=True)
 x=s.add_parser('start');x.add_argument('--group',choices=list('ABC'),required=True);x.add_argument('--ids',default='all');x.add_argument('--concurrency',type=int,default=1);x.add_argument('--round',type=int)
 x=s.add_parser('execute');x.add_argument('--id',type=int,required=True);x.add_argument('--rep',type=int,default=1);x.add_argument('--approval',required=True)
 x=s.add_parser('observe');x.add_argument('--id',type=int,required=True);x.add_argument('--rep',type=int,default=1);x.add_argument('--group',required=True,choices=list('ABC'));x.add_argument('--phase',choices=['planning','execution'],required=True)
 x=s.add_parser('ingest');x.add_argument('--id',type=int,required=True);x.add_argument('--rep',type=int,default=1);x.add_argument('--group',required=True,choices=list('ABC'));x.add_argument('--file',required=True)
 s.add_parser('collect');a=p.parse_args();root=Path(a.runner).resolve();m=load(root/'manifest.json');t.BASE=m['base_url'];t.MODEL=m['model_id']
 if a.action=='start':
  tasks=[x for x in m['tasks'] if (a.ids=='all' or str(x['id']) in a.ids.split(',')) and (a.round is None or x.get('round')==a.round)]
  with concurrent.futures.ThreadPoolExecutor(max_workers=a.concurrency) as pool:
   futures=[pool.submit(start,root,task,rep,a.group) for task in tasks for rep in range(1,m['repetitions']+1)]
   for f in futures:f.result()
 elif a.action=='execute':execute(root,a.id,a.rep,a.approval)
 elif a.action=='observe':observe(runpath(root,a.id,a.rep,a.group),a.phase,root)
 elif a.action=='ingest':ingest(root,a.id,a.rep,a.group,a.file)
 else:collect(root)
if __name__=='__main__':main()
