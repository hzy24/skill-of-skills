"""One-shot Yuanjing API experiment driver. No resending, no solution feedback."""
import argparse,hashlib,json,re,threading,time,uuid,urllib.request,urllib.parse
from pathlib import Path
BASE=None;MODEL=None
op=urllib.request.build_opener(urllib.request.ProxyHandler({}))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2))
def get(path):return json.load(op.open(BASE+path,timeout=45))
def post(path,v):return json.load(op.open(urllib.request.Request(BASE+path,data=json.dumps(v).encode(),headers={'Content-Type':'application/json'}),timeout=90))
def upload(cid,f):
 boundary=uuid.uuid4().hex
 data=(f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{f.name}"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode()+f.read_bytes()+f'\r\n--{boundary}--\r\n'.encode())
 return json.load(op.open(urllib.request.Request(BASE+f'/api/chat/{cid}/upload',data=data,headers={'Content-Type':'multipart/form-data; boundary='+boundary}),timeout=90))
def environment():
 plugins=get('/api/plugins')
 for p in plugins['plugins']:
  p.pop('user_config',None);p.pop('mcp',None)
 return {'plugins':plugins,'skills':get('/api/skills')}

def delivered_paths(snap):
 import html
 paths=set()
 for e in snap.get('events',[]):
  if e.get('tool_name')=='PresentToUser' and e.get('kind')=='tool_result' and not e.get('is_error'):
   content=e.get('content','')
   if isinstance(content,str):
    paths.update(html.unescape(x.strip()) for x in re.findall(r'<file_path>(.*?)</file_path>',content,re.S))
 return paths

def download(cid,out,snap):
 paths=delivered_paths(snap)
 artifacts=out/'artifacts';artifacts.mkdir(exist_ok=True);records=[]
 for path in sorted(paths):
  try:
   data=op.open(BASE+'/api/files/'+cid+'?'+urllib.parse.urlencode({'path':path,'download':'true'}),timeout=90).read()
   f=artifacts/(hashlib.sha256(path.encode()).hexdigest()[:8]+'-'+Path(path).name);f.write_bytes(data)
   records.append({'source':path,'saved':str(f.relative_to(out)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
  except Exception as e:records.append({'source':path,'error':str(e)})
 save(out/'artifacts.json',records)

