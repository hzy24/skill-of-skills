Fig. 2 | Skill of Skills compared with direct task execution across 24 tasks.

(a) Mean task-normalized scores: A = 100 by construction and C = 132.4. (b) Distribution of task-level percentage gains over A; dots represent all 24 tasks, the box spans the interquartile range with median line, whiskers indicate the full range, and the diamond marks the mean. (c) Gains for each task in supplied order; the dashed line indicates the mean gain of 32.4%. C exceeds A on all 24 supplied pairs, with gains of 26.8–41.3%.

Each task is normalized independently to its own A score. A's constant normalized value does not imply equal raw baseline scores or zero raw-score variance. The mean of per-task gains need not equal improvement in aggregate raw scores. One reported observation per group and task; no repeated-run variance, significance, runtime or causal claim is made. Data supplied by the user; task order is not a verified benchmark instance identifier.

Outputs: 183 × 179 mm; 600 dpi PNG, editable-text SVG and font-embedded PDF. Source data and Python reproduction script are included. Prior B/C figures are retained unchanged.
