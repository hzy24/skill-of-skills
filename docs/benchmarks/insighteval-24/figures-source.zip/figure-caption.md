Fig. 1 | Paired comparison of matched professional skills and Skill of Skills across 24 tasks.

(a) Distributions of task-normalized scores for B (matched skills) and C (Skill of Skills). Each point denotes one task; boxes show the median and interquartile range, whiskers the full observed range, and diamonds the means. Horizontal jitter is used only for readability. (b) Within-task B/C comparison with equal axis scales; the dashed line denotes equality. (c) Paired differences, C minus B, in input order. Colors identify the higher-performing group.

A is normalized to 100 separately for each task. The mean indices are 129.8 (B) and 132.4 (C), with a mean paired difference of 2.60 points; C is higher on 15/24 tasks. This is a descriptive visualization of the supplied, rounded normalized scores, with one reported observation per group per task. No repeated-run variance, raw-score aggregate improvement, runtime comparison or statistical-significance claim is implied. Task order is not a verified benchmark instance identifier.

绘图检查：24组数据全部保留；未平滑、删点或挑选任务。固定宽度183 mm，PNG 600 dpi；SVG保留文字，PDF嵌入字体。已检查导出预览并修正标题与脚注间距。
