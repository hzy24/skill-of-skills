# 专业委托与成果收尾

收到“按方案执行”后读取任务目录最新 plan.json。HTML 保存不启动任务；页面保存失败先修复保存，执行以成功写回的版本为准。新任务先用 `flow.py <任务目录> status` 确认 phase=delivered；缺交付时按返回的 next_tool 和 receipt_command 补齐。旧任务核对 handoff.py 的交付记录。首次使用用户审阅后的执行原话；复核技能适配、安装与宿主入口。所有核心业务模块都须由专业 Skill 承担。

若原任务为 planning_failed，原样发送返回的 final_reply 并结束。失败终态优先于残留 plan.json、聊天替代方案和普通执行确认；安装、准备、换绑及执行入口均检查原任务状态。用户另行要求修复或交办新任务时，再处理该项新指令。

## 每个模块的公开命令

### 1. 交接

```
python <skill>/scripts/execute.py open <任务目录>/plan.json --node N1 --evidence '按方案执行'
```

脚本读取当前方案，检查依赖与输入版本，初始化或协调 run.json，输出本模块的业务委托、所选方法、上游文件、receipt.json 路径和下一条完整命令。授权参数填写用户确认原话，不填写模型对初始任务的授权推断；授权已登记后可省略。needs_plan_delivery 时先交付并登记附件；awaiting_user_confirmation 时结束回复等待用户。若返回 preparation_required，按返回的 ready 命令核验并登记，再次 open。外部技能先取得具体安装授权。不要读源码寻找准备字段，也不要根据 plan_hash 是否存在猜测方案是否编译。

按业务委托与真实 Skill 指令执行。成熟 Skill 自主安排内部分析、草稿、计算与修复；SoS 只管理范围、交接与成果标准。方法已在当前上下文读取且版本不变时直接采用；按需读取资源，避免重复全文加载。执行新专业方法前先确认它已绑定本模块。采用可迁移方法时，委托中保留负责范围、比较理由与判断边界；按方案使用已有制度或交接给约定能力，专业结论遵循已说明的依据。

open 返回 outputs 绝对路径和 submit 完整命令。按约定路径生成成果，将真实工具输出、测试结果或具体方法执行记录保存到 open 返回的 execution_log 绝对路径，也可复用已有日志。--applied 说明方法如何用于本次成果。仅复制技能原文或输入材料不足以证明执行；无需编辑 receipt。

生成的路径省去重复目录歧义。自行使用相对路径时，一律相对 plan.json 所在目录。CLI 的 plan/--state 等文件参数按当前命令工作目录解释，返回的下一步命令均使用绝对路径。

### 2. 提交成果及已有日志

```
python <skill>/scripts/execute.py submit <任务目录>/plan.json --node N1 --record <真实检查日志路径> --applied "实际采用的方法及结果"
```

成果路径不同于 open 返回值时加 --output D1_1=/实际路径，可重复添加。日志缺失时指明实际路径。多技能模块返回 usage_file 和带 --usage 的 submit 命令；在该文件逐个填写 skill、record、applied，无需改 receipt 或维护协议字段。辅助整理模块没有技能绑定时直接 submit。

自动读取交接单、绑定、方法原文和实际文件，生成技能使用记录、格式检查结果与 review.json。模型不填写哈希、candidate_id 或第二套合约。提交前检查文件非空和已知格式的基本完整性，日志保存为独立快照；同一原始日志继续追加不会改写已验收证据。程序检查文件关联和版本；宿主负责核读方法采用与成果内容。

### 3. 审阅并完成

读取实际成果，对照 review.json 的各项 criteria，填写 result、locator、method、observed。pass 表示该项已按所写方法检查通过；尚未检查用 unverified，存在问题用 fail。随后：

```
python <skill>/scripts/execute.py accept <任务目录>/plan.json --node N1
```

程序检查审阅完整性、输入与成果版本，通过后完成节点。专业或跨文件交付按 [质量检查](delivery-quality.md) 核对事实、数字与实际视觉。专业 Skill 有验证器时使用 [原生验证](native-checks.md)。检查内容来自本次需求与方法，不增加无关检查。

## 修正与恢复

- 待审成果或执行日志需要修正：修改实际文件后再次 capture，再填写新审阅表并 accept。旧审阅自动失效，历史快照保留；无需 fail → start 重跑整个任务。
- 最终跨文件检查发现已完成模块需要修正：`execute.py reopen <任务目录>/plan.json --node N1 --evidence <具体问题>` 重开该模块与下游，保留历史记录和当前范围授权，然后 open、修正并重新验收。
- 来源材料或方法原文改变：重新评估影响，reconcile 并在明确授权下启动受影响模块。不能用成果刷新掩盖输入变化。
- 自动检查失败：重新 open 返回 repair_required；修正成果后 submit，不新增启动次数。待审模块重新 open 返回现有审阅表；已完成模块返回 complete。
- 任务被中断且模块仍 running：重新 open 获取当前委托，已有填写的 receipt 保留；先查看现有文件与日志，再接续工作。
- 方案出现用户修改：重新 open 会协调执行记录。保留不受影响节点；重置节点和下游需要按最新范围重新核验与授权。
- 协议报错按输出的字段或下一步命令处理；同类问题两次无进展就保留短诊断并报告阻塞，不继续猜字段或反复阅读整份源码。

run.json 由脚本更新。修改其中哈希会触发一致性校验；出现损坏时保留现场，用新 --state 重新核验。校验码用于发现脚本外修改，同一宿主仍可改动所有本地文件，不能将其解释为身份认证或防篡改凭证。

## 实际需要换用技能

当现有绑定无法承担本模块成果，选好并读取新 Skill 原文，先在提案中说明新技能的大小、来源、理由和依赖，取得针对该提案的安装授权后安装。把一个 [业务草案 skills 对象](draft-format.md) 保存为 replacement.json；无需重写完整方案。然后：

```
python <skill>/scripts/rebind.py <任务目录>/plan.json --node N2 --skill replacement.json --base-hash <open返回的plan_hash> --reason '新技能覆盖本模块需要的制作与验证能力，原技能只支持分析' --verification '实际入口、依赖及检查工具的核验结果'
```

原因与核验内容按真实情况填写。该命令用于单个 Skill 完整负责一个模块，原子保存新方案，更新候选、方法输入、需求选择和绑定，重置本模块及下游，保留其他节点。已有用户编辑以版本检查保护。打开 HTML 的用户需加载最新方案。

换用后重新 open，按新 Skill 完成工作、重新核验可复用成果，再 capture/accept。不要把实际 docx/xlsx 等调用登记为原分析技能。换用命令不证明新技能已经执行。多技能分支或改变用户要求的交付范围时，重新对齐分工；需要新增安装权限或业务取舍时沿用会话授权边界处理。

## 交付与人工节点

所有模块完成后：

```
python <skill>/scripts/execute.py audit <任务目录>/plan.json
```

核对文件与输入版本，再逐项回应用户目标，将最终文件通过宿主附件交付。预算接近上限时先保留成果和真实检查记录；尚未验收的文件明确标为草稿，避免反复重做整份产物。audit 不负责上传，文件存在也不代表用户已收到。没有完成的检查和未解决问题如实说明。

人工决定节点保留兼容入口：`sos.py start ... --state ... --node ...` 后保存用户真实决定，再用 `sos.py review ... --artifacts <输出ID到决定文件的JSON> --evidence <确认原文>` 完成。由宿主生成决定记录，用户无需填写协议。

执行状态串行更新。新入口与 HTML 保存共用文件锁；旧 sos.py 状态命令留作兼容，不与新入口同时写账本。宿主结束后不宣称仍在监督任务。

新方案的专业适配与计划履约核对见 [方法适配与计划履约](composed-methods.md)。open 返回 needs_method_review 时按返回命令重开适配表，不能用 ready 绕过。实际采用的辅助技能也要进入分工；submit 的 --trace 可接宿主真实工具调用列表。

## 按阶段推进

当前计划的节点代表业务阶段。同一 Skill 连续负责多个节点时，复用已读取且版本未变的方法、已获准的安装与上游结果；当前节点只处理自己的问题与产出。逐阶段 open / submit / accept 记录结果，无需用户重复确认原方案内的正常推进。不同 Skill 的交接通过上游结果完成。

`delivery_role=intermediate` 为阶段结果，保存在任务目录用于复核和下游工作；`final` 为向用户交付的文件。两类均须真实生成并检查。最终交付按最新 plan.json 的 final 清单。用户调整阶段、依赖、成果或完成标准后，读取最新方案，复核受影响节点并重新协调执行状态。

方案适配需要复核时，运行 execute.py 返回的 method_review.py open 命令。新方案使用只读 context_file 与独立 review_file；只填写 need、verdict、reason，随后运行返回的 next_command。未变化阶段的判断自动复用。
