"""Reproduce the figure from the provided 24 paired normalized scores."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
P=Path(__file__).resolve().parent
raw=json.loads((P/'data.json').read_text());v=np.asarray(raw['data']);b,c=v.T;d=c-b
PURPLE='#8173AD';PINK='#C96F98';INK='#292735';GRAY='#928F9C';GRID='#EAE7EF'
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':7.5,'axes.titlesize':9,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'text.color':INK,'axes.labelcolor':INK,'xtick.color':INK,'ytick.color':INK,'axes.edgecolor':'#B1ADB9','axes.linewidth':.6,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42,'savefig.facecolor':'white'})
fig=plt.figure(figsize=(7.2,7.05),facecolor='white')
gs=fig.add_gridspec(2,2,left=.095,right=.965,bottom=.18,top=.86,wspace=.48,hspace=.53,width_ratios=[1,1.05])
a=fig.add_subplot(gs[0,0]);bb=fig.add_subplot(gs[1,0]);cc=fig.add_subplot(gs[:,1])
def label(ax,letter,title):
 ax.text(-.19,1.065,letter,transform=ax.transAxes,weight='bold',fontsize=11,va='bottom');ax.set_title(title,loc='left',pad=12)
label(a,'a','Score distributions');label(bb,'b','Within-task comparison');label(cc,'c','Paired advantage by task')
# All observations shown; jitter only separates coincident marks, not values.
rng=np.random.default_rng(7)
for x,vals,col in [(0,b,PURPLE),(1,c,PINK)]:
 box=a.boxplot([vals],positions=[x],widths=.36,patch_artist=True,showfliers=False,whis=(0,100),medianprops={'color':col,'lw':1.6},boxprops={'facecolor':col+'25','edgecolor':col,'lw':.8},whiskerprops={'color':col,'lw':.8},capprops={'color':col,'lw':.8})
 a.scatter(np.full(24,x)+rng.uniform(-.1,.1,24),vals,s=13,c=col,edgecolors='white',linewidths=.35,zorder=3,alpha=.9)
 a.scatter(x+.28,vals.mean(),marker='D',s=27,c=col,zorder=5)
 a.text(x+.29,vals.mean()+1.4,f'{vals.mean():.1f}',fontsize=8,ha='center',weight='bold',color=col)
a.set_xticks([0,1],['B\nMatched skills','C\nSkill of Skills']);a.set_xlim(-.5,1.55);a.set_ylim(117,146);a.set_yticks([120,125,130,135,140,145]);a.set_ylabel('Normalized score (A = 100)');a.grid(axis='y',color=GRID,lw=.5);a.set_axisbelow(True)
a.text(.02,.98,'n = 24 tasks per group',transform=a.transAxes,va='top',fontsize=7,color=GRAY)
a.legend(handles=[Line2D([],[],marker='D',ls='',color=INK,markersize=4,label='Mean')],loc='lower right',frameon=False,fontsize=7)
# Equal scales ensure the diagonal is a true equality line.
lo,hi=118,144
bb.fill([lo,lo,hi],[lo,hi,hi],PINK,alpha=.055,zorder=0);bb.fill([lo,hi,hi],[lo,lo,hi],PURPLE,alpha=.045,zorder=0)
bb.plot([lo,hi],[lo,hi],color=GRAY,lw=.8,ls=(0,(3,3)))
for mask,col,marker in [(d>0,PINK,'o'),(d<0,PURPLE,'s')]:bb.scatter(b[mask],c[mask],c=col,s=21,marker=marker,edgecolors='white',lw=.45,zorder=3)
bb.set_xlim(lo,hi);bb.set_ylim(lo,hi);bb.set_aspect('equal',adjustable='box');bb.set_xticks([120,130,140]);bb.set_yticks([120,130,140]);bb.set_xlabel('B: matched skills');bb.set_ylabel('C: Skill of Skills');bb.text(.04,.95,'C > B: 15 tasks',transform=bb.transAxes,va='top',color=PINK,fontsize=7.5);bb.text(.96,.06,'B > C: 9 tasks',transform=bb.transAxes,ha='right',color=PURPLE,fontsize=7.5)
# Fixed input order, no sorting that hides losses or implies task identity.
y=np.arange(24)
cc.axvline(0,color=GRAY,lw=.8,zorder=1)
cc.barh(y,d,height=.57,color=np.where(d>0,PINK,PURPLE),alpha=.86,zorder=2)
for i,delta in enumerate(d):cc.text(delta+(.18 if delta>0 else -.18),i,f'{delta:+.1f}',ha='left' if delta>0 else 'right',va='center',fontsize=6.7)
cc.set_yticks(y,[f'{i:02d}' for i in range(1,25)]);cc.set_ylim(23.8,-1.2);cc.set_xlim(-7.1,9.2);cc.set_xticks([-5,0,5]);cc.set_xlabel('C − B (normalized-score points)');cc.set_ylabel('Task order');cc.tick_params(axis='y',length=0);cc.spines['left'].set_visible(False);cc.grid(axis='x',color=GRID,lw=.5);cc.set_axisbelow(True)
cc.text(.02,1.005,'B higher',transform=cc.transAxes,color=PURPLE,fontsize=7);cc.text(.98,1.005,'C higher',transform=cc.transAxes,color=PINK,fontsize=7,ha='right')
fig.text(.095,.974,'Skill of Skills: paired evaluation across 24 tasks',fontsize=12,weight='bold',va='top')
fig.text(.095,.936,'Task-normalized scores  •  Baseline A = 100  •  One reported pair per task',fontsize=7.4,color=GRAY)
fig.text(.095,.080,'Mean C − B: +2.60 points     |     C wins: 62.5%     |     Mean-index ratio C/B: +2.00%',fontsize=8,weight='bold')
fig.text(.095,.033,'Boxes: median and IQR; whiskers: full range. Dots: individual tasks. Diamonds: means.\nTask labels follow input order. Scores are normalized per task; no raw-score or runtime comparison is implied.',fontsize=6.7,color=GRAY,linespacing=1.6)
for ext in ['png','pdf','svg']:fig.savefig(P/f'benchmark24-paper.{ext}',dpi=600)
fig.savefig(P/'benchmark24-preview.png',dpi=180)
print('Exported PNG (600 dpi), PDF, SVG; figure size 183 × 179 mm')
plt.close(fig)
