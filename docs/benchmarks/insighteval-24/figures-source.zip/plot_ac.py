"""Reproduce the figure from the provided 24 paired normalized scores."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
P=Path(__file__).resolve().parent
raw=json.loads((P/'data.json').read_text());v=np.asarray(raw['data']);b,c=v.T;d=c-b
PURPLE='#8173AD';PINK='#C96F98';INK='#292735';GRAY='#928F9C';GRID='#EAE7EF'
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':7.5,'axes.titlesize':9,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'text.color':INK,'axes.labelcolor':INK,'xtick.color':INK,'ytick.color':INK,'axes.edgecolor':'#B1ADB9','axes.linewidth':.6,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42,'savefig.facecolor':'white'})
gain=c-100
fig=plt.figure(figsize=(7.2,7.05),facecolor='white')
gs=fig.add_gridspec(2,2,left=.095,right=.965,bottom=.18,top=.86,wspace=.48,hspace=.56,width_ratios=[1,1.05])
a=fig.add_subplot(gs[0,0]);bb=fig.add_subplot(gs[1,0]);cc=fig.add_subplot(gs[:,1])
def label(ax,letter,title):
 ax.text(-.19,1.065,letter,transform=ax.transAxes,weight='bold',fontsize=11,va='bottom');ax.set_title(title,loc='left',pad=12)
label(a,'a','Mean normalized scores');label(bb,'b','Distribution of task-level gains');label(cc,'c','Improvement over A by task')
a.bar([0,1],[100,c.mean()],width=.55,color=[GRAY,PINK],alpha=.85,zorder=3)
for x,val in [(0,100),(1,c.mean())]:a.text(x,val+3,f'{val:.1f}',ha='center',va='bottom',weight='bold',fontsize=9)
a.set_xticks([0,1],['A\nDirect task','C\nSkill of Skills']);a.set_ylim(0,158);a.set_yticks([0,50,100,150]);a.set_xlim(-.6,1.6);a.set_ylabel('Normalized score (A = 100)');a.grid(axis='y',color=GRID,lw=.5);a.set_axisbelow(True)
a.axhline(100,color=GRAY,lw=.7,ls=(0,(3,3)),zorder=2)
# Distribution represents between-task variation, not repeated model runs.
bb.boxplot([gain],positions=[0],orientation="horizontal",widths=.34,patch_artist=True,showfliers=False,whis=(0,100),medianprops={'color':PINK,'lw':1.8},boxprops={'facecolor':PINK+'25','edgecolor':PINK,'lw':.8},whiskerprops={'color':PINK,'lw':.8},capprops={'color':PINK,'lw':.8})
rng=np.random.default_rng(7)
bb.scatter(gain,rng.uniform(.30,.55,24),color=PINK,s=16,edgecolor='white',lw=.4,zorder=3)
bb.scatter(gain.mean(),-.36,marker='D',c=PINK,s=30,zorder=4)
bb.text(gain.mean(),-.52,f'Mean +{gain.mean():.1f}%',ha='center',va='top',fontsize=8,color=PINK,weight='bold')
bb.set_ylim(-.92,.95);bb.set_xlim(24,44);bb.set_xticks([25,30,35,40]);bb.set_yticks([]);bb.set_xlabel('Improvement over A (%)');bb.spines['left'].set_visible(False);bb.grid(axis='x',color=GRID,lw=.5);bb.set_axisbelow(True)
bb.text(.02,.96,'Median +31.35%\nRange +26.8% to +41.3%',transform=bb.transAxes,va='top',fontsize=7.5,color=GRAY,linespacing=1.65)
y=np.arange(24)
cc.barh(y,gain,height=.57,color=PINK,alpha=.86,zorder=2)
for i,delta in enumerate(gain):cc.text(48.5,i,f'+{delta:.1f}%',ha='right',va='center',fontsize=6.7)
cc.axvline(gain.mean(),color=INK,lw=.8,ls=(0,(3,3)),zorder=3)
cc.text(gain.mean(),-1.1,'Mean +32.4%',ha='center',va='bottom',fontsize=7,color=INK)
cc.set_yticks(y,[f'{i:02d}' for i in range(1,25)]);cc.set_ylim(23.8,-1.8);cc.set_xlim(0,49);cc.set_xticks([0,10,20,30,40]);cc.set_xlabel('Improvement over A (%)');cc.set_ylabel('Task order');cc.tick_params(axis='y',length=0);cc.spines['left'].set_visible(False);cc.grid(axis='x',color=GRID,lw=.5);cc.set_axisbelow(True)
fig.text(.095,.974,'Skill of Skills versus direct task execution',fontsize=12,weight='bold',va='top')
fig.text(.095,.936,'24 tasks  •  Baseline A = 100 per task  •  One reported observation per group and task',fontsize=7.4,color=GRAY)
fig.text(.095,.080,'Mean task-level gain: +32.4%     |     C > A: 24 / 24 tasks     |     Lowest gain: +26.8%',fontsize=8,weight='bold')
fig.text(.095,.033,'A is fixed at 100 by normalization; this does not imply zero variability in raw baseline scores.\nBox: median and IQR; whiskers: full range. Dots: tasks. Diamond: mean. Task labels follow input order.',fontsize=6.7,color=GRAY,linespacing=1.6)
for ext in ['png','pdf','svg']:fig.savefig(P/f'benchmark24-ac-paper.{ext}',dpi=600)
fig.savefig(P/'benchmark24-ac-preview.png',dpi=180);plt.close(fig)
