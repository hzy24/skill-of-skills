#!/usr/bin/env python3
"""Invoke the installed official CLI; preserve raw outputs and version evidence."""
import argparse,subprocess,json,sys
from pathlib import Path
from bench import save,sha
p=argparse.ArgumentParser();p.add_argument('--predictions',required=True);p.add_argument('--data-dir',required=True);p.add_argument('--official-repo',required=True);p.add_argument('--output',required=True);a=p.parse_args();out=Path(a.output)
if out.exists():raise SystemExit('Use a fresh official-score output directory')
out.mkdir(parents=True)
revision=subprocess.check_output(['git','-C',a.official_repo,'rev-parse','HEAD'],text=True).strip()
dirty=subprocess.check_output(['git','-C',a.official_repo,'status','--porcelain'],text=True)
# Run the checked-out source explicitly, rather than an unrelated PATH installation.
import os
env=dict(os.environ);env['PYTHONPATH']=str(Path(a.official_repo).resolve()/'src')
rows=[]
for f in sorted(Path(a.predictions).glob('*.json')):
 instance=int(f.stem.split('-')[0]);cmd=[sys.executable,'-m','insighteval.cli','evaluate','--instance',str(instance),'--data-dir',str(Path(a.data_dir).resolve()),'--predictions',str(f.resolve())]
 result=subprocess.run(cmd,capture_output=True,text=True,env=env);(out/(f.stem+'.stdout')).write_text(result.stdout);(out/(f.stem+'.stderr')).write_text(result.stderr)
 try:score=json.loads(result.stdout) if result.returncode==0 else None
 except json.JSONDecodeError:score=None
 rows.append({'key':f.stem,'returncode':result.returncode,'score':score,'prediction_sha256':sha(f),'command':cmd})
save(out/'official-results.json',{'official_revision':revision,'working_tree_changes':dirty,'metric':'official CLI local ROUGE; no LLM judge implied','rows':rows})
if not rows or any(x['score'] is None for x in rows):raise SystemExit(1)
