# Skill of Skills · 24 题 ABC 独立评测工具包

默认从 InsightEval 100 题中**无放回随机抽取 4 轮 × 6 题，共 24 道不同题目**；每题 A/B/C 各运行一次，总计 **72 次业务任务运行**。四轮是四批不同题目，并非同一批题重复四次。固定种子 `20261105`，抽样清单运行前落盘，不根据结果换题。

本包由启动脚本、成果采集、英译审阅格式、本地评分、官方 CLI 评分入口、实验协议和返回结果要求组成。**整理脚本不意味着已启动这 72 次实验。**

## 1. 环境准备

Python 3.10+；本工具本身只用标准库。运行官方评分时按 InsightEval 的 pyproject 安装依赖。启动适配器面向元景桌面本地 API，默认地址 `http://127.0.0.1:62774`；其他部署由官方映射同等会话接口。API 不是 OpenAI Chat Completions 接口。

请自行获取数据和官方评分代码，记录 Git commit；包内不复制未明确授权分发的第三方仓库。

```bash
git clone https://github.com/zhenghaozhu23/InsightEval.git InsightEval
python3 -m venv .venv
source .venv/bin/activate
pip install -e ./InsightEval
python3 -m unittest discover -s tests -v
```

SoS 固定为本次已有实验使用的 `1.1.2-rc.5`，源码位于 `frozen-skill/`。如官方选择其他版本，必须重新准备一个独立实验目录，不在中途替换。官方安装冻结版本并检查可发现性；脚本不修改元景客户端或全局技能市场。

## 2. 一次抽样，固定四轮

```bash
python3 scripts/bench.py prepare \
  --dataset ./InsightEval \
  --skill ./frozen-skill \
  --output ./experiment-24 \
  --model YOUR_YUANJING_MODEL_ID \
  --rounds 4 --per-round 6 --repetitions 1 --seed 20261105
```

输出分离：

- `experiment-24/runner/`：运行端需要的任务、CSV、冻结 SoS 和 manifest。
- `experiment-24/evaluator/`：参考答案和协议记录，**只交评分端，不挂载到任务沙箱或翻译环境**。
- `runner/manifest.json → sampling.rounds`：四轮题号、随机种子、候选池和总运行次数。

默认使用官方原始 `goal`，不把标准答案、参考洞见、问题清单或评分反馈提供给任务模型。如测试日常语言简化需求，提供 `--prompts prompts.json`，格式为 `{"1":"需求…", "2":"需求…"}`，应覆盖抽中的全部题目；脚本标记为 `everyday-adapted`。两类协议各自汇总，不能冒充完全相同的测试。

使用相同原始业务需求和成果格式，区别仅为分组技能安排。所有组交付 `findings.json`，避免由 DOCX/HTML 表格拆段方式决定得分。

## 3. 分组与隔离

| 组 | 配置 |
|---|---|
| A | 直接交办；普通原生工具可用，不调用 SoS 或专业技能 |
| B | 不调用 SoS；使用 C 实际读取/调用的相同专业及交付技能、相同文件版本，自己组织步骤 |
| C | SoS 规划 → 审阅具体计划及安装提案 → 确认执行 → 交付 |

每题每组新建独立会话。官方必须隔离技能可见范围、工作目录与跨会话记忆：仅提示词禁止不构成技术隔离。A/B 不能读 C 的方案、结论或计算结果。B 唯一继承物是经审查的技能原文件。

把 `examples/environment-attestation.json` 填写后放到 `runner/environment-attestation.json`。其中 model_id 必须匹配；如元景部署不能隔离技能，先调整运行环境，不能把未隔离实验宣称为严格对照。

## 4. 启动第 1 轮 C 规划

```bash
python3 scripts/run.py --runner experiment-24/runner start --group C --round 1 --concurrency 6
```

第 2/3/4 轮使用 `--round 2/3/4`。一次启动六个独立会话，不在同一个聊天框连续回答六题。环境不允许六路时降低 concurrency，ABC 使用相同并发策略。

规划上限默认 1800 秒，执行阶段不设置业务总超时。HTTP 连接超时仅意味着断线：只继续观察，不重发请求、不杀远端执行。每个请求在发送前落盘；不确定是否发出也不自动重发。

恢复单个会话：

```bash
python3 scripts/run.py --runner experiment-24/runner observe --id 23 --rep 1 --group C --phase planning
```

`23` 是示例，应替换成抽中题号。`runner/STOP` 文件暂停本地观察与后续启动；不会停止已经运行的远端模型。需真正终止远端任务时由操作者在元景或对应 stop API 明确停止，并记录原因。

## 5. 审阅计划、确认执行

核对 C 附件中 plan.json/plan.html 已交付；审阅安装的技能名称、链接、文件清单和版本。填写 `examples/approval.json`：plan SHA256 必须是本次附件的哈希；execution_prompt 只包含执行确认与具体安装授权，不提供分析答案或改进建议。

```bash
python3 scripts/run.py --runner experiment-24/runner execute --id 23 --rep 1 --approval approval-23.json
```

其余五题同理。C 无计划、失败或缺少实际技能使用证据时，记录失败/缺失，跳过该题 B，A 仍可测试。不能补跑到成功后只报告成功。

## 6. 收集 C，固定 B 技能，再启动 A/B

每组执行后 `artifacts.json` 保存下载文件路径和 SHA256。选择实际交付的 findings.json 导入：

```bash
python3 scripts/run.py --runner experiment-24/runner ingest --id 23 --rep 1 --group C \
  --file experiment-24/runner/runs/23/1/C/artifacts/HASH-findings.json
```

模型漏交 findings.json 时保留失败记录，不通过额外追问补充新分析。若另做离线人工成果提取，应单独预注册统一规则并保留原文映射，本包默认不静默这样做。

将 C 实际使用的技能完整文件复制到 `runner/frozen-methods/题号/…`，在 `runs/题号/1/C/matched-skills.json` 填入 `examples/matched-skills.json` 格式。审核需检查执行事件正文：Read、Skill、Bash cat/sed 等均可构成证据；仅在计划里提及技能不算。文件哈希必须与 C 使用版本相同，不从市场拉最新版本替代。

脚本检查审阅签名、事件 ID 存在与文件 SHA256；**具体事件是否证明使用该技能由审阅者负责判断**。这部分保留显式审阅，避免仅凭技能名字自动制造“匹配成功”。

```bash
python3 scripts/run.py --runner experiment-24/runner start --group A --round 1 --concurrency 6
python3 scripts/run.py --runner experiment-24/runner start --group B --round 1 --concurrency 6
```

B 按题核验 C 成果及技能审阅后才能发送。也可用 `--ids 23,27` 只启动已具备条件的题目。A/B 同样 ingest 实际交付的 findings.json。重复执行 start 不重发已发送任务；重复 ingest 不覆盖已有预测。

## 7. 英译与评分

原生英文成果直接评分。中文成果先生成独立英译审阅表：

```bash
python3 scripts/bench.py translations --runner experiment-24/runner --output experiment-24/translations
```

译者只看原成果，不看参考答案。填写每段 english、reviewed_by；保留错误、数值、推断力度和限制，不总结、不补洞见。脚本校验源文件哈希、原文、段落编号和覆盖数量。翻译的模型/人员、版本、时间和消耗应另行记录，不混入任务消耗。

```bash
python3 scripts/bench.py score \
  --runner experiment-24/runner \
  --references experiment-24/evaluator/references.json \
  --translations experiment-24/translations \
  --output experiment-24/evaluation
```

输出逐题分数、每轮均值、完整共同样本均值、C−A/C−B 配对差值和按题 bootstrap 95% 区间。失败/缺失/未译不记 0，单独统计覆盖率；不能拿不同覆盖样本的 available_means 直接比较。四轮只有24题，区间仅描述此样本的不确定性。

再由官方仓库 CLI 独立重算：

```bash
python3 scripts/official_score.py \
  --predictions experiment-24/evaluation/official-predictions \
  --data-dir InsightEval/data --official-repo InsightEval \
  --output experiment-24/official-scores
```

该脚本记录官方仓库 commit、工作区变化、每次命令及原始 stdout/stderr。公开 CLI 是 ROUGE 最佳匹配评分；若官方还提供语义评价/新颖性评价，应返回评审模型、版本、提示词、参数与逐题分数，不能与 ROUGE 混称。

## 8. 资源统计与回传

```bash
python3 scripts/run.py --runner experiment-24/runner collect
```

回传整个 runner/runs、resources.json、manifest.json、英译记录、evaluation 与 official-scores，以及环境配置。详见 `OFFICIAL_REQUEST.md`。

C 耗时包含规划和执行，审批等待单独记录；Token 按事件 ID 去重，输入包含缓存时不重复叠加。缺失 usage 有计数，不解释成零消耗。原始输出、失败、人工审批、额外操作均保留。

## 验证范围

本包通过离线逻辑测试及24题/100题材料准备检查；未在官方部署实际运行72次请求。元景 API 适配器沿用本线程已用接口，官方应先做环境连通与隔离检查。`VALIDATION.md` 记录实际检查结果。
